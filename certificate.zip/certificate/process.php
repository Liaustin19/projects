<?php
require_once 'connection.php';
require_once 'path.php';
require_once 'class/crud_class.php';
require_once 'class/dprot_class.php';

//admin sign in
if(isset($_POST['pass'])){
    $email = protect::check($conn, $_POST['eml']);
    $pass = md5(protect::check($conn, $_POST['pass']));
    
    $ar = "WHERE user= '$email' AND pass='$pass'";
    
    $qu = crud::select('admin', $ar, $conn);
    if (mysqli_num_rows($qu) == 1) {
        $rw = mysqli_fetch_array($qu);

        $_SESSION['admin'] = $rw['user'];
        echo 'success';
        
    } else {
        echo 'incorrect email or password';
    }
}

//add record
if (isset($_POST['fname'])) {
    $fname = protect::check($conn, $_POST['fname']);
    $regno = protect::check($conn, $_POST['regno']);
    $sdep = protect::check($conn, $_POST['sdep']);
    $program = protect::check($conn, $_POST['program']);
    $Ssession = protect::check($conn, $_POST['Ssession']);
    $remark = protect::check($conn, $_POST['remark']);

    if (!empty($fname) && !empty($regno) && !empty($sdep) && !empty($program) && !empty($Ssession) && !empty($remark)) {
        $args1 = "WHERE regno='$regno'";
        $q = crud::select('records', $args1, $conn);

        if (mysqli_num_rows($q) == 0) {
            # new records
            $args = "regno='$regno',name='$fname',dep='$sdep',program='$program',session='$Ssession',remark='$remark'";
            if (crud::insert('records', $args, $conn)) {
                echo 'Saved';
            } else {
                echo 'error occur!';
            }
        } else {
            # update records
            $args = "name='$fname',dep='$sdep',program='$program',session='$Ssession',remark='$remark' WHERE regno='$regno'";
            if (crud::update('records', $args, $conn)) {
                echo 'Saved';
            } else {
                echo 'error occur!';
            }
        }
    }
}

//add new admin
if (isset($_POST['aEml'])) {
    $aEml = protect::check($conn, $_POST['aEml']);
    $apass = md5(protect::check($conn, $_POST['apass']));

    if (!empty($aEml) && !empty($apass)) {
        $args1 = "WHERE user='$aEml'";
        $q = crud::select('admin', $args1, $conn);

        if (mysqli_num_rows($q) == 0) {
            # new admin
            $args = "user='$aEml', pass='$apass'";
            if (crud::insert('admin', $args, $conn)) {
                echo 'Success';
            } else {
                echo 'error occur!';
            }
        } else {
            echo 'User already exists!';
        }
    }
}

# get all records
if (isset($_POST['getRec'])) {
    $q = crud::select('records', 'ORDER BY dep AND name ASC', $conn);
    $i=0;
    while ($r = mysqli_fetch_array($q)) {
        $i++;
        ?>
        <tr>
            <td><?php echo $i; ?></td>
            <td><img src="<?php echo $r['passport']; ?>" alt="" width="30px" style="border-radius: 50%;"> <?php echo $r['name']; ?></td>
            <td><?php echo $r['regno'] ?></td>
            <td>
                <form action="<?php echo root; ?>rec" method="POST">
                    <input type="hidden" name="stdReg" value="<?php echo $r['regno'] ?>">

                    <input type="submit" name="editStd" value="Edit" class="btn-primary">

                    &nbsp; 
                    <input type="button" value="Delete" class="btn-danger" onclick="dellstud('<?php echo $r['regno'] ?>', '<?php echo $r['name']; ?>');">
                </form>
            </td>
        </tr>
        <?php
    }
}

# get all adm
if (isset($_POST['getAdm'])) {
    $online = $_SESSION['admin'];
    $q = crud::select('admin', "WHERE user!='admin@gmail.com' AND user!='$online' ORDER BY user ASC", $conn);
    $i=0;
    while ($r = mysqli_fetch_array($q)) {
        $i++;
        ?>
        <tr>
            <td><?php echo $i; ?></td>
            <td><?php echo $r['user']; ?></td>
            <td>
                <input type="button" value="Delete" class="btn-danger" onclick="dellAdm('<?php echo $r['user'] ?>');">
            </td>
        </tr>
        <?php
    }
}

# delete record
if (isset($_POST['dl_Studt'])) {
    $studnt_ID = protect::check($conn, $_POST['studnt_ID']);

    if (!empty($studnt_ID)) {
        crud::del('records', "regno='$studnt_ID'", $conn);
    }
}

# delete admin
if (isset($_POST['dl_Adm'])) {
    $adm_ID = protect::check($conn, $_POST['adm_ID']);

    if (!empty($adm_ID)) {
        crud::del('admin', "user='$adm_ID'", $conn);
    }
}

# get scanned student info
if (isset($_POST['ScannedReg'])) {
    $ScannedReg = protect::check($conn, $_POST['ScannedReg']);

    $q = crud::select('records', "WHERE regno='$ScannedReg'", $conn);
    $rr = mysqli_fetch_array($q);
    ?>
    <!-- <div class="m-f-r"> -->
        <!-- <div class="mfr-60" style="padding-left: 10px"> -->
        <div style="padding-left: 10px">
            <strong>Name: </strong> <?php echo $rr['name']; ?> <br>
            <strong>Regno: </strong> <?php echo $rr['regno']; ?> <br>
            <strong>Department: </strong> <?php echo $rr['dep']; ?> <br>
            <strong>Remark: </strong> <?php echo $rr['remark']; ?>
        </div>
    <!-- </div> -->
    <br>
    <?php
}


?>