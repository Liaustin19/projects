<?php
session_destroy();
header('Location: '.root.'lgn');
?>