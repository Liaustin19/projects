<?php
$conn = mysqli_connect("localhost", "root", "", "certificatever");
session_start();
?>