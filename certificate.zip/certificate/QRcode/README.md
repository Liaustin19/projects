# QRcode-Generator-in-PHP
A QR code generator demo using phpqrcode library.

QR(Quick Response) codes are a popular type of two-dimensional barcode. They are also known as hardlinks or
physical world hyperlinks. QR Codes store up to 4,296 alphanumeric characters of arbitrary text. 

This is a sample project to generate QR code on the fly. 
This project uses phpqrcode open source library to generate qr code.
In this project some random numbers are generated to show in QR code.

To scan QR code using android device take a look at 

https://github.com/tanzeerH/Zbar_in_Android_Studio
