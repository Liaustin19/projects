<?php
require_once 'connection.php';
require_once 'path.php';
require_once 'class/crud_class.php';
require_once 'class/dprot_class.php';

if (isset($_POST['printEcard'])) {
    // $semester = protect::check($conn, $_POST['semester']);
    // $session = protect::check($conn, $_POST['session']);
    $regno = protect::check($conn, $_POST['regno']);
    $dep = protect::check($conn, $_POST['dep']);
    // $stream = protect::check($conn, $_POST['stream']);

    if (!empty($regno)) {
        $arg = "WHERE regno='$regno'";
    } else {
        $arg = "WHERE dep='$dep' ORDER BY name ASC";
    }

    # QRcode Generator
    //set it to writable location, a place for temp generated PNG files
    $PNG_TEMP_DIR = dirname(__FILE__).DIRECTORY_SEPARATOR.'temp'.DIRECTORY_SEPARATOR;
    
    //html PNG location prefix
    $PNG_WEB_DIR = 'temp/';

    include "QRcode/qrlib.php";    
    
    //ofcourse we need rights to create temp dir
    if (!file_exists($PNG_TEMP_DIR))
        mkdir($PNG_TEMP_DIR);

    //processing form input
    //remember to sanitize user input in real-life solution !!!
    $errorCorrectionLevel = 'H';
    $matrixPointSize = 4;

    ?>
        <!DOCTYPE html>
        <html lang="en">

        <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <title>
            CERTIFICATE
        </title>
        <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
        <!--     Fonts and icons     -->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
        <link rel="stylesheet" href="<?php echo root; ?>font_awesome/fontawesome-4.3.0.min.css">
        <!-- CSS Files -->
        <link href="<?php echo root; ?>assets/css/bootstrap.min.css" rel="stylesheet" />

        <style>
            body {
                padding-top: 60px !important;
                padding-bottom: 60px !important;
            }

            .container {
                border: 1px solid black;
                padding: 40px;
                margin-bottom: 60px !important;
            }

            .m-f-r {
                display: -ms-flexbox;
                display: flex;
                -ms-flex-wrap: wrap;
                flex-wrap: wrap;
                margin-right: 15px;
                margin-left: 15px;
            }

            .mfr-22 {
                -ms-flex: 0 0 22%;
                flex: 0 0 22%;
                max-width: 22%;
            }
            
            .mfr-78 {
                -ms-flex: 0 0 78%;
                flex: 0 0 78%;
                max-width: 78%;
            }

            .mfr-60 {
                -ms-flex: 0 0 60%;
                flex: 0 0 60%;
                max-width: 60%;
            }
            .mfr-70 {
                -ms-flex: 0 0 70%;
                flex: 0 0 70%;
                max-width: 70%;
            }

            .mfr-40 {
                -ms-flex: 0 0 40%;
                flex: 0 0 40%;
                max-width: 40%;
            }

            .mfr-20 {
                -ms-flex: 0 0 20%;
                flex: 0 0 20%;
                max-width: 20%;
            }
            .mfr-15 {
                -ms-flex: 0 0 15%;
                flex: 0 0 15%;
                max-width: 15%;
            }

            .mfr-50 {
                -ms-flex: 0 0 50%;
                flex: 0 0 50%;
                max-width: 50%;
            }

            .mfr-13 {
                -ms-flex: 0 0 13%;
                flex: 0 0 13%;
                max-width: 13%;
            }
            .mfr-37 {
                -ms-flex: 0 0 37%;
                flex: 0 0 37%;
                max-width: 37%;
            }
        </style>
        </head>

        <body>
            <input type="button" value="GO" onclick="javascript::print();" class="btn btn-primary" id="btn">
            <a href="<?php echo root; ?>rec" class="btn btn-primary">Back</a>
    <?php
        
    $q = crud::select('records', $arg, $conn);
    while ($r = mysqli_fetch_array($q)) {
        
        
        $filename = $PNG_TEMP_DIR.$r['name'].'.png';
        
        //default data    
        QRcode::png($r['regno'], $filename, $errorCorrectionLevel, $matrixPointSize, 2);

        $gdp = crud::select('department', "WHERE depname='".$r['dep']."'", $conn);
        $dprw = mysqli_fetch_array($gdp);
        if ($r['program'] == 'Higher National Diploma') {
            $mmmprog = 'HND';
        } elseif ($r['program'] == 'National Diploma') {
            $mmmprog = 'ND';
        } else {
            $mmmprog = 'DIP';
        }
        ?>
            <div class="container ddprnt" style="background-color:white;">
                <div style="text-align:center;"><img src="<?php echo root; ?>assets/img/favicon.png" width="60px" alt=""></div>
                <div class="m-f-r">
                    <div class="mfr-15">
                        <img src="<?php echo root; ?>assets/img/favicon.png" width="60px" alt="">
                    </div>
                    <div class="mfr-70 text-center">
                        <h1>THE FEDERAL POLYTECHNIC, BAUCHI</h1>
                        <h6>PMB 0231, BAUCHI</h6>
                        <p>info@fptb.edu.ng | www.fptb.edu.ng</p>
                    </div>
                    <div style="text-align:right" class="mfr-15">
                        <img src="<?php echo root; ?>assets/img/favicon.png" width="60px" alt="">
                    </div>
                </div><br><br>
                <h3 class="text-center">OFFICE OF THE REGISTRAR</h3>

                <div class="m-f-r">
                    <div class="mfr-40">Ref: <span style="border-bottom: 1px solid black; padding-bottom: 6px;">FPTB/<?php echo $dprw['abrv'].'/'.$mmmprog.'/'.$r['regno']; ?></span></div>
                    <div class="mfr-20"></div>
                    <div class="mfr-40">Date: <span style="border-bottom: 1px solid black; padding-bottom: 6px;"><?php echo date("d F, Y"); ?></span></div>
                </div><br><br><br><br>

                <h4 class="text-center"><i>Statement of Result</i></h4><br><br><br>


                <p class="text-center">This is to certify that</p>
                <h2 class="text-center" style="border-bottom:1px dotted black;"><?php echo $r['name']; ?></h2><br>

                <p class="text-center">having successfully completed an approved course of study</p>
                <h3 class="text-center" style="border-bottom:1px dotted black;"><?php echo $r['dep']; ?></h3><br>

                <p class="text-center">has been awarded with</p>
                <h4 class="text-center" style="border-bottom:1px dotted black; text-transform: uppercase;"><?php echo $r['program'].' AT '.$r['remark']; ?></h4><br>
                
                <p class="text-center">by the Academic Board of the Federal Polytechnic, Bauchi <br> this day</p>
                <h4 class="text-center" style="border-bottom:1px dotted black;"><?php echo date('d').' '.date('F, Y'); ?></h4><br>

                <div class="m-f-r">
                    <div class="mfr-15">
                        <img src="<?php echo root; ?>assets/img/favicon.png" width="60px" alt="">
                    </div>
                    <div class="mfr-20">
                        <?php
                        echo '<img src="'.$PNG_WEB_DIR.basename($filename).'" />';
                        ?>
                    </div>
                    <div class="mfr-50 text-center">
                        
                    </div>
                    <div style="text-align:right" class="mfr-15">
                        <img src="<?php echo root; ?>assets/img/favicon.png" width="60px" alt="">
                    </div>
                </div>
            </div>
        <?php
    }
    ?>
    <!--   Core JS Files   -->
    <script src="<?php echo root; ?>assets/js/core/jquery.min.js"></script>
    <script src="<?php echo root; ?>cdnjs/html2canvas.js"></script>
    <script src="<?php echo root; ?>jsPDF-1.0.272/dist/jspdf.debug.js"></script>
    <script src="<?php echo root; ?>custom.js"></script>
    </body>

    </html>
    <?php
}

?>