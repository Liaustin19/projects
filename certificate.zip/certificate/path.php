<?php
define('root', '/'.substr(__DIR__, strrpos(__DIR__, '\\')+1).'/');
define('permit', 'YES');
// SERVER_NAME
define('SERVER_NAME', 'http://localhost'.root);
?>