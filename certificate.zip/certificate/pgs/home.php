    <?php
    if (!defined('permit')) {
        exit('<br><br><br><h1>Error 404</h1><h2>Object not found!</h2>');
    }

    if (@$_SESSION['admin'] != "") {
        ?><script>window.location = '<?php echo root; ?>rec';</script><?php
    }
    ?>
    
    <div class="container">
      <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-4 text-center" style="margin-top: 100px; background-color: rgba(0,0,0,0.25); padding: 20px; border-radius: 5px;">
          <img src="<?php echo root; ?>assets/img/favicon.png" alt="" width="100px">
          <h2 class="font-weight-bolder text-info">Log In</h2>

          <form id="Lgnform">
            <p class="alert-warning" id="Algnreply"></p>
            <input type="email" class="form-control" placeholder="Email" name="eml" id="eml" required><br>

            <input type="password" class="form-control" placeholder="Password" name="pass" id="pass" required><br>

            <button type="submit" class="btn btn-primary w-100">Sign in</button>
          </form>
        </div>
      </div>
    </div>