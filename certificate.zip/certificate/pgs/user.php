    <?php
    if (!defined('permit')) {
        exit('<br><br><br><h1>Error 404</h1><h2>Object not found!</h2>');
    }

    if (@$_SESSION['admin'] == "") {
        ?><script>window.location = '<?php echo root; ?>lgn';</script><?php
    }

    if (isset($_POST['editStd'])) {
        $stdReg = protect::check($conn, $_POST['stdReg']);
        $gs = crud::select('records', "WHERE regno='$stdReg'", $conn);
        $grow = mysqli_fetch_array($gs);
    }
    ?>

    <div class="main-panel" id="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent  bg-primary  navbar-absolute">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <div class="navbar-toggle">
              <button type="button" class="navbar-toggler">
                <span class="navbar-toggler-bar bar1"></span>
                <span class="navbar-toggler-bar bar2"></span>
                <span class="navbar-toggler-bar bar3"></span>
              </button>
            </div>
            <a class="navbar-brand" href="#pablo">Add Students Record</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end" id="navigation">
            <ul class="navbar-nav">
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
      <div class="panel-header panel-header-sm">
      </div>
      <div class="content">
        <div class="row">
          <div class="col-md-11">
            <div class="card">
              <div class="card-header">
                <h5 class="title">Add Record</h5>
              </div>
              <div class="card-body">
                <div style="border-radius: 0.1875rem; height: 350px;">
                  <form id="addStudRecfrm">
                    <div class="row">
                      <div class="col-md-4 pr-1">
                        <div class="form-group">
                          <label for="fname">Full Name</label>
                          <input type="text" class="form-control" name="fname" id="fname" placeholder="Full Name" <?php if (!empty($grow['name'])) { echo 'value="'.$grow['name'].'"'; } ?> required>
                        </div>
                      </div>
                      <div class="col-md-4 px-1">
                        <div class="form-group">
                          <label for="regno">Reg no</label>
                          <input type="text" class="form-control" name="regno" id="regno" placeholder="Reg no" <?php if (!empty($grow['regno'])) { echo 'value="'.$grow['regno'].'"'; } ?> required>
                        </div>
                      </div>
                      <div class="col-md-4 pl-1">
                        <div class="form-group">
                          <label for="Ssession">Session</label>
                          <select name="Ssession" id="Ssession" class="form-control" required>
                            <option value="">-- select session --</option>
                            <?php
                            $y1 = 2019;
                            $y2 = 2020;
                            while (($y1 < date('Y')) && ($y2 <= date('Y'))) {
                                $y1++; $y2++;
                                ?>
                                <option value="<?php echo $y1.'/'.$y2; ?>" <?php if (!empty($grow['session']) && ($grow['session'] == $y1.'/'.$y2)) { echo 'selected'; } ?>><?php echo $y1.'/'.$y2; ?></option>
                                <?php
                            }
                            ?>
                          </select>
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      <div class="col-md-4 pr-1">
                        <div class="form-group">
                          <label for="sdep">Department</label>
                          <select name="sdep" id="sdep" class="form-control" required>
                            <option value="">-- select department --</option>
                            <?php
                            $q = crud::select('department', "ORDER BY depname ASC", $conn);
                            while ($rr = mysqli_fetch_array($q)) { ?>
                                <option value="<?php echo $rr[1]; ?>" <?php if (!empty($grow['dep']) && ($grow['dep'] == $rr[1])) { echo 'selected'; } ?>><?php echo $rr[1]; ?></option>
                            <?php } ?>
                          </select>
                        </div>
                      </div>
                      <div class="col-md-4 px-1">
                        <div class="form-group">
                          <label for="program">Programme</label>
                          <select name="program" id="program" class="form-control" required>
                            <option value="">-- select program --</option>
                            <option value="Higher National Diploma" <?php if (!empty($grow['program']) && ($grow['program'] == 'Higher National Diploma')) { echo 'selected'; } ?>>HND</option>
                            <option value="National Diploma" <?php if (!empty($grow['program']) && ($grow['program'] == 'National Diploma')) { echo 'selected'; } ?>>ND</option>
                            <option value="Ordinary Diploma" <?php if (!empty($grow['program']) && ($grow['program'] == 'Ordinary Diploma')) { echo 'selected'; } ?>>OND</option>
                          </select>
                        </div>
                      </div>
                      <div class="col-md-4 pr-1">
                        <div class="form-group">
                          <label for="stream">Remark</label>
                          <select name="remark" id="remark" class="form-control" required>
                            <option value="">-- select remark --</option>
                            <option value="Distinction" <?php if (!empty($grow['remark']) && ($grow['remark'] == 'Distinction')) { echo 'selected'; } ?>>Distinction</option>
                            <option value="Upper credit" <?php if (!empty($grow['remark']) && ($grow['remark'] == 'Upper credit')) { echo 'selected'; } ?>>Upper credit</option>
                            <option value="Lower credit" <?php if (!empty($grow['remark']) && ($grow['remark'] == 'Lower credit')) { echo 'selected'; } ?>>Lower credit</option>
                            <option value="Pass" <?php if (!empty($grow['remark']) && ($grow['remark'] == 'Pass')) { echo 'selected'; } ?>>Pass</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      <div class="col-md-2 pl-1">
                        <div class="form-group">
                          <br>
                          <input type="submit" value="Submit" class="btn btn-primary">
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>

        <style>
          .form-control {
            height: 40px !important;
          }
        </style>

        <form method="POST" action="card.php">
          <h3 class="text-center">Print Certificate</h3>
          <div class="row">
            <!-- <div class="col-md-4">
              <select name="session" id="session" class="form-control" required>
                <option value="">-- select session --</option>
                <?php
                $y1 = 2019;
                $y2 = 2020;
                while (($y1 < date('Y')) && ($y2 <= date('Y'))) {
                    $y1++; $y2++;
                    ?>
                    <option value="<?php echo $y1.'/'.$y2; ?>"><?php echo $y1.'/'.$y2; ?></option>
                    <?php
                }
                ?>
              </select><br>
            </div> -->

            <div class="col-md-4">
              <input type="text" name="regno" id="regno" class="form-control" placeholder="Reg no (optional)" onkeyup="stdReg(this.value);"><br>
            </div>

            <div class="col-md-4 tgs">
              <select name="dep" id="dep" class="form-control">
                <option value="">-- select department --</option>
                <?php
                $q = crud::select('department', "ORDER BY depname ASC", $conn);
                while ($rr = mysqli_fetch_array($q)) { ?>
                    <option value="<?php echo $rr[1]; ?>"><?php echo $rr[1]; ?></option>
                <?php } ?>
              </select><br>
            </div>

            <div class="col-md-4">
              <input type="submit" value="Submit" name="printEcard" class="btn btn-primary">
            </div>
          </div>
        </form>
      </div>
      