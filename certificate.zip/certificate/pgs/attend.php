<?php
    if (!defined('permit')) {
        exit('<br><br><br><h1>Error 404</h1><h2>Object not found!</h2>');
    }

    if (@$_SESSION['admin'] == "") {
        ?><script>window.location = '<?php echo root; ?>lgn';</script><?php
    }
    ?>

    <style>
      .form-control {
        height: 40px !important;
      }
      #video {
        border: 2px solid blue;
        box-shadow: 2px 2px 3px black;
        width:320px;
        height:240px;
      }
      #canvas {
        display:none;
      }
      .camera {
        width: 340px;
        display:inline-block;
      }
      .output {
        width: 300px;
        display:inline-block;
      }
      #startbutton {
        cursor: pointer;
        background-color: rgba(0, 150, 0, 0.5);
        border: 1px solid rgba(255, 255, 255, 0.7);
        box-shadow: 0px 0px 1px 2px rgba(0, 0, 0, 0.2);
        font-size: 14px;
        font-family: "Lucida Grande", "Arial", sans-serif;
        color: rgba(255, 255, 255, 1.0);
      }
      .contentarea {
        font-size: 16px;
        font-family: "Lucida Grande", "Arial", sans-serif;
      }
      .m-f-r {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap;
        margin-right: 15px;
        margin-left: 15px;
      }
      .mfr-20 {
        -ms-flex: 0 0 20%;
        flex: 0 0 20%;
        max-width: 20%;
      }
      .mfr-40 {
        -ms-flex: 0 0 40%;
        flex: 0 0 40%;
        max-width: 40%;
      }
      .mfr-50 {
        -ms-flex: 0 0 50%;
        flex: 0 0 50%;
        max-width: 50%;
      }
      .mfr-60 {
        -ms-flex: 0 0 60%;
        flex: 0 0 60%;
        max-width: 60%;
      }
    </style>

    <div class="main-panel" id="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg  bg-primary  navbar-absolute">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <div class="navbar-toggle">
              <button type="button" class="navbar-toggler">
                <span class="navbar-toggler-bar bar1"></span>
                <span class="navbar-toggler-bar bar2"></span>
                <span class="navbar-toggler-bar bar3"></span>
              </button>
            </div>
            <a class="navbar-brand" href="#pablo">Verify Certificate</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end" id="navigation">
            
          </div>
        </div>
      </nav>

      <!-- End Navbar -->
      <div class="panel-header panel-header-sm">
      </div>

      <div class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title">Scan QRcode</h4>
              </div>
              <div class="card-body">
                <div class="map" style="height: 40vh; overflow-y: scroll;">
                  <div class="contentarea">
                    <div class="camera">
                      <video id="video">Video stream not available.</video>
                    </div>

                    <div class="output">
                      <button id="startbutton">Scan</button>
                      
                      <br><br>OR <br><br>

                      <h6>Scan from File:</h6>
                      <input type="file" id="file-selector"><br><br>
                    </div>

                    <div class="output">
                      <b>Detected QR code:</b><br>
                      <div id="file-qr-result">None</div><br><br>
                    </div>

                    <canvas id="canvas"></canvas>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <script type="module">
        import QrScanner from "../scan-qr/qr-scanner.min.js";
        QrScanner.WORKER_PATH = '../scan-qr/qr-scanner-worker.min.js';
      
        const fileSelector = document.getElementById('file-selector');
        const fileQrResult = document.getElementById('file-qr-result');
      
        function setResult(label, result) {
          if (result != 'No QR code found') {
            $.ajax({
              method: 'POST',
              url: root()+'process.php',
              data: {
                ScannedReg: result
              },
              success: function(res) {
                $('#file-qr-result').html(res);
              },
              dataType: 'text'
            });
          } else {
            label.textContent = result;
            label.style.color = 'teal';
            clearTimeout(label.highlightTimeout);
            label.highlightTimeout = setTimeout(() => label.style.color = 'inherit', 100);
          }
        }
      
        // ####### File Scanning #######
        fileSelector.addEventListener('change', event => {
          const file = fileSelector.files[0];
          if (!file) {
            return;
          }
          QrScanner.scanImage(file)
            .then(result => setResult(fileQrResult, result))
            .catch(e => setResult(fileQrResult, e || 'No QR code found.'));
        });

        (function() {
          // The width and height of the captured photo. We will set the
          // width to the value defined here, but the height will be
          // calculated based on the aspect ratio of the input stream.

          var width = 320;    // We will scale the photo width to this
          var height = 0;     // This will be computed based on the input stream

          // |streaming| indicates whether or not we're currently streaming
          // video from the camera. Obviously, we start at false.

          var streaming = false;

          // The various HTML elements we need to configure or control. These
          // will be set by the startup() function.

          var video = null;
          var canvas = null;
          var startbutton = null;

          function startup() {
            video = document.getElementById('video');
            canvas = document.getElementById('canvas');
            startbutton = document.getElementById('startbutton');

            navigator.mediaDevices.getUserMedia({video: true, audio: false})
            .then(function(stream) {
            video.srcObject = stream;
            video.play();
            })
            .catch(function(err) {
            console.log("An error occurred: " + err);
            });

            video.addEventListener('canplay', function(ev){
            if (!streaming) {
              height = video.videoHeight / (video.videoWidth/width);
            
              // Firefox currently has a bug where the height can't be read from
              // the video, so we will make assumptions if this happens.
            
              if (isNaN(height)) {
              height = width / (4/3);
              }
            
              video.setAttribute('width', width);
              video.setAttribute('height', height);
              canvas.setAttribute('width', width);
              canvas.setAttribute('height', height);
              streaming = true;
            }
            }, false);

            startbutton.addEventListener('click', function(ev){
            takepicture();
            ev.preventDefault();
            }, false);
            
            clearphoto();
          }

          // Fill the photo with an indication that none has been
          // captured.

          function clearphoto() {
            var context = canvas.getContext('2d');
            context.fillStyle = "#AAA";
            context.fillRect(0, 0, canvas.width, canvas.height);

            var data = canvas.toDataURL('image/png');
          }
          
          // Capture a photo by fetching the current contents of the video
          // and drawing it into a canvas, then converting that to a PNG
          // format data URL. By drawing it on an offscreen canvas and then
          // drawing that to the screen, we can change its size and/or apply
          // other changes before drawing it.

          function takepicture() {
            var context = canvas.getContext('2d');
            if (width && height) {
              canvas.width = width;
              canvas.height = height;
              context.drawImage(video, 0, 0, width, height);
              
              var data = canvas.toDataURL('image/png');
              
              QrScanner.scanImage(data)
                .then(result => setResult(fileQrResult, result))
                .catch(e => setResult(fileQrResult, e || 'No QR code found.'));
            } else {
              clearphoto();
            }
          }

          // Set up our event listener to run the startup process
          // once loading is complete.
          window.addEventListener('load', startup, false);
        })();
      </script>