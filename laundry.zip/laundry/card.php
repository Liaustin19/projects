<?php
include 'db_connect.php';
if (isset($_GET['recId'])) {
    $recId = $_GET['recId'];
    # QRcode Generator
    //set it to writable location, a place for temp generated PNG files
    $PNG_TEMP_DIR = dirname(__FILE__).DIRECTORY_SEPARATOR.'temp'.DIRECTORY_SEPARATOR;
    
    //html PNG location prefix
    $PNG_WEB_DIR = 'temp/';

    include "QRcode/qrlib.php";    
    
    //ofcourse we need rights to create temp dir
    if (!file_exists($PNG_TEMP_DIR))
        mkdir($PNG_TEMP_DIR);

    //processing form input
    //remember to sanitize user input in real-life solution !!!
    $errorCorrectionLevel = 'H';
    $matrixPointSize = 4;

    ?>
        <!DOCTYPE html>
        <html lang="en">

        <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <title>
            LAUNDRY CARD
        </title>
        <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />

        <style>
            body {
                font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
                padding-top: 60px !important;
                padding-bottom: 60px !important;
                overflow-x: hidden;
            }

            html {
                font-family: sans-serif;
                -webkit-text-size-adjust: 100%;
                -ms-text-size-adjust: 100%;
                -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
            }

            .container {
                text-align: center;
                padding: 40px;
                margin-bottom: 60px !important;
            }

            .btn {
                padding: 5px;
                background-color: blue;
                color: white;
                border: none;
                cursor: pointer;
                text-decoration: none;
            }

            @media print {
                .btn {
                    display: none;
                }

                .container {
                    width: 100vw;
                    height: 100vh;
                    border: 0px;
                    padding: 40px;
                    margin-bottom: 0px !important;
                }
            }

            * {
                -webkit-print-color-adjust:exact !important;
                color-adjust: exact !important;
            }
        </style>
        </head>

        <body>
            <input type="button" value="PRINT" class="btn" onclick="javascript:print();">
            <a href="landpade.php" class="btn">Back</a>
    <?php
    $q = mysqli_query($conn, "SELECT * FROM laundry_list WHERE id='$recId'");
    $r = mysqli_fetch_array($q);
        
    $filename = $PNG_TEMP_DIR.$recId.'.png';

    //default data    
    QRcode::png($r['tag'], $filename, $errorCorrectionLevel, $matrixPointSize, 2);
    ?>
    <div class="container" style="background-color:white;">
    <div>
        <p>Customer name: 
        <strong><?php echo $r['customer_name']; ?></strong></p>
    </div>
    <div>
        <p>Queue number: 
        <strong><?php echo $r['queue']; ?></strong></p>
    </div>
    <div>
        <p>Total amount: 
        <strong><?php echo $r['total_amount']; ?></strong></p>
    </div>
    <p style="border-bottom: 3px solid black;"></p>

    <div>
        <?php
        echo '<img src="'.$PNG_WEB_DIR.basename($filename).'" />';
        ?>
    </div>
    </div>
        
    </body>

    </html>
    <?php
}

?>