<?php
if (!defined('permit')) {
	exit('<br><br><br><h1>Error 404</h1><h2>Object not found!</h2>');
}

if (@$_SESSION['admin'] != "admin") {
	?><script>window.location = '<?php echo root; ?>';</script><?php
}

if (isset($_POST['editUser'])) {
    $stfEml = protect::check($conn, $_POST['edUemail']);
    $gs = crud::select('user', "WHERE email='$stfEml'", $conn);
    $grow = mysqli_fetch_array($gs);
}
?>
	<!--Navbar -->
 <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
      <!-- <a class="navbar-brand" href="home" style="color: blue;">Young_<span style="color:red;">AB</span></a> -->
        
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-333"
        aria-controls="navbarSupportedContent-333" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
        
      <div class="collapse navbar-collapse" id="navbarSupportedContent-333">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo root; ?>admin"></i> Examiner</a>
            </li>

          <li class="nav-item">
            <a class="nav-link" href="<?php echo root; ?>panelau"></i> Auditor</a>
          </li>
            
          <li class="nav-item">
            <a class="nav-link" href="<?php echo root; ?>paneleo"></i> Exam Officer</a>
          </li>

		  	<li class="nav-item">
				<a class="nav-link" href="<?php echo root; ?>tran"></i> Transaction</a>
			</li>

			<li class="nav-item">
				<a class="nav-link active" href="<?php echo root; ?>verf"></i> Verification</a>
			</li>

		  <li class="nav-item">
            <a class="nav-link" href="<?php echo root; ?>out"></i> Log out</a>
          </li>
        </ul>
    </div>
</nav>
<!--/.Navbar -->

<form id="verify_results" enctype="multipart/form-data">
  <div class="row" style="margin-top: 100px; padding-left: 10px;">
    <div class="col-md-3">
      <input class="form-control" type="text" name="vcCode" id="vcCode" placeholder="Course Code" required>
    </div>

    <div class="col-md-3">
      <input class="form-control" type="file" name="verFile" id="verFile" onchange="valImg2('verFile');" required>
    </div>

    <div class="col-md-3">
      <input class="btn btn-primary" type="submit" value="Verify">
    </div>

    <div class="col-md-3"></div>
    <div class="col-md-3"><br><div class="alert alert-success" id="verResp"></div></div>
  </div>
</form>