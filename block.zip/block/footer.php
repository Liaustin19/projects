    <!-- Jquery JS -->
    <script src="<?php echo root; ?>js/jquery.js"></script>
    <!-- Bootstrap JS -->
    <script src="<?php echo root; ?>bootstrap-4.4.1-dist/js/bootstrap.min.js"></script>
    <!-- Main JS -->
    <script src="<?php echo root; ?>main.js"></script>
    <!-- Sheet Js -->
    <script src="<?php echo root; ?>js/xlsx.full.min.js"></script>
</body>
</html>