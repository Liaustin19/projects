    <head>
        <!-- custom css file link  -->
        <link rel="stylesheet" href="<?php echo root; ?>style.css">
        <style>
            body {
                background-color: white;
            }

            a {
                text-decoration: none !important;
            }
        </style>
    </head>
    <!-- header section starts  -->

    <header class="header">

        <a href="def" class="logo"> <i class="fa fa-user-graduate"></i> Federal Polytechnic Bauchi </a>

        <div id="menu-btn" class="fa fa-bars"></div>

        <nav class="navbar">
            <ul>
                <li><a href="def">HOME</a></li>
                <li><a href="#">ABOUT</a></li>
                <li><a href="#">BLOG</a></li>
                <li><a href="home">LOGIN</a></li>
            </ul>
        </nav>

    </header>

    <!-- header section ends -->

    <!-- home section starts  -->

    <section class="home">

        <div class="image">
            <img src="<?php echo root; ?>images/home-img.png" alt="">
        </div>

        <div class="content">
            <h3>FPTB Result Processing System using Blockchain Technology</h3>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Culpa cumque neque quam amet perferendis sed rem ut tenetur porro praesentium.</p>
            <a href="#" class="btn">Read More</a>
        </div>

    </section>

    <!-- home section ends -->

    <!-- categories section starts  -->

    <section class="category">

        <a href="#" class="box">
            <img src="<?php echo root; ?>images/category-1.png" alt="">
            <h3>computer science</h3>
        </a>

        <a href="#" class="box">
            <img src="<?php echo root; ?>images/category-2.png" alt="">
            <h3>biology & life</h3>
        </a>

        <a href="#" class="box">
            <img src="<?php echo root; ?>images/category-3.png" alt="">
            <h3>business analysis</h3>
        </a>

        <a href="#" class="box">
            <img src="<?php echo root; ?>images/category-4.png" alt="">
            <h3>social science</h3>
        </a>

        <a href="#" class="box">
            <img src="<?php echo root; ?>images/category-5.png" alt="">
            <h3>data analysis</h3>
        </a>

    </section>

    <!-- categories section ends -->

    <!-- footer section starts  -->

    <section class="footer">

        <div class="box-container">

            <div class="box">
                <h3>explore</h3>
                <a href="#"> <i class="fa fa-arrow-right"></i> HOME </a>
                <a href="#"> <i class="fa fa-arrow-right"></i> ABOUT </a>
                <a href="#"> <i class="fa fa-arrow-right"></i> GALLERY </a>
                <a href="#"> <i class="fa fa-arrow-right"></i> BLOG </a>
                <a href="#"> <i class="fa fa-arrow-right"></i> CONTACT US </a>
            </div>

            <div class="box">
                <h3>Follow US</h3>
                <a href="#"> <i class="fa fa-facebook-f"></i> facebook </a>
                <a href="#"> <i class="fa fa-twitter"></i> twitter </a>
                <a href="#"> <i class="fa fa-linkedin"></i> linkedin </a>
                <a href="#"> <i class="fa fa-instagram"></i> instagram </a>
                <a href="#"> <i class="fa fa-youtube"></i> youtube </a>
                <a href="#"> <i class="fa fa-github"></i> github </a>
            </div>

        </div>

        <div class="credit"> created by <span>Lukzee (AKA: Tenn Whiterose)</span> | all rights reserved! </div>

    </section>

    <!-- footer section ends -->