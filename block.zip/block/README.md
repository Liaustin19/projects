# blockchainv2
This repository shows how Blockchain Technology is integrated into result processing system for higher institution.
This software work by tracking changes made in the report sheet XLXS File submitted by the Examiner to the Exam officer or Auditor
This is the advance version of <a href="https://github.com/Lukzee/blockchain">this</a>
