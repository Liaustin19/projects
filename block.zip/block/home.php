 <head>
	<link rel="stylesheet" href="style2.css" />
	<style>
		select {
			color: black !important;
		}
		input::placeholder {
			color: beige !important;
		}
	</style>
 </head>
    <div class="container">
      <span class="big-circle"></span>
      <img src="<?php echo root; ?>images/shape.png" class="square" alt="" />
      <div class="form">
        <div class="contact-info">
          <h3 class="title">FPTB, Bauchi</h3>
          <p class="text">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Saepe
            dolorum adipisci recusandae praesentium dicta!
          </p>

          <div class="info">
            <div class="information">
              <img src="<?php echo root; ?>images/location.png" class="icon" alt="" />
              <p>Gwallamegi, Bauchi state.</p>
            </div>
            <div class="information">
              <img src="<?php echo root; ?>images/email.png" class="icon" alt="" />
              <p>fptb@gmail.com</p>
            </div>
            <div class="information">
              <img src="<?php echo root; ?>images/phone.png" class="icon" alt="" />
              <p>021 2250888</p>
            </div>
          </div>

          <div class="social-media">
            <p>Connect with us :</p>
            <div class="social-icons">
              <a href="#">
                <i class="fa fa-facebook-f"></i>
              </a>
              <a href="#">
                <i class="fa fa-twitter"></i>
              </a>
              <a href="#">
                <i class="fa fa-instagram"></i>
              </a>
              <a href="#">
                <i class="fa fa-linkedin"></i>
              </a>
            </div>
          </div>
        </div>

        <div class="contact-form">
          <span class="circle one"></span>
          <span class="circle two"></span>

          <form id="loginfrm">
            <h3 class="title">Contact us</h3>
            <div class="input-container">
              <input type="email" name="email" class="input" id="email" placeholder="Email" required />
            </div>

            <div class="input-container">
              <input type="password" name="password" id="password" class="input" placeholder="Password" required />
			</div>

            <div class="input-container">
              	<select name="role" id="role" class="input" required>
 					<option value="">select user type</option>
 					<option value="admin">Admin</option>
 					<option value="examiner">Examiner</option>
 					<option value="auditor">Auditor</option>
 					<option value="exam-officer">Exam Officer</option>
 				</select>
            </div>

			<br>
            <input type="submit" name="login" value="Login" class="btn" /><br><br>
			<a href="<?php echo root; ?>def"><button type="button" class="btn">Go Back To Homepage</button></a>
          </form>
        </div>
      </div>
    </div>

